package firsttests.pages;

import firsttests.utils.WebElementActions;
import org.openqa.selenium.WebDriver;

import java.io.IOException;

public class LoginPage {

    WebElementActions web;

    public LoginPage (WebDriver driver) throws IOException {
        web = new WebElementActions(driver);
    }


    public void inputUserLogin(String inputData) throws IOException {
        web.input("login.page.username", inputData);
    }

    public void inputUserPassword(String inputData) throws IOException {
        web.input("login.page.password", inputData);
    }

    public void clickLoginButton() throws IOException {
        web.clickButton("login.page.submit.button");
    }

    public void errorPopup() throws IOException {
        boolean isPresent = web.isElementPresent("login.page.error.popup");
        System.out.println("Popup appeared " + isPresent);

        if (isPresent) {
            String popupErrorMessage = web.getElementText("login.page.error.popup");
            System.out.println("Error message is:" + popupErrorMessage);
        }
    }
}
