package firsttests.pages;

import firsttests.utils.WebElementActions;
import org.openqa.selenium.WebDriver;

import java.io.IOException;

public class RegisterPage {

    WebElementActions web;

    public RegisterPage (WebDriver driver) throws IOException {
        web = new WebElementActions(driver);
    }


    public void inputUserFirstName(String firstName) throws IOException {
        web.input("reg.page.first.name", firstName);
    }

    public void inputUserLastName(String lastName) throws IOException {
        web.input("reg.page.last.name", lastName);
    }

    public void inputUserMiddleName(String middleName) throws IOException {
        web.input("reg.page.middle.name", middleName);
    }

    public void inputUserEmail(String userEmail) throws IOException {
        web.input("reg.page.email.name", userEmail);
    }

    public void inputUserConfirmEmail(String userConfirmEmail) throws IOException {
        web.input("reg.page.confirm.email.name", userConfirmEmail);
    }

    public void inputUserPhone(String userPhone) throws IOException {
        web.input("reg.page.phone", userPhone);
    }

    public void inputUserMobPhone(String userMobPhone) throws IOException {
        web.input("reg.page.mobile.phone",userMobPhone);
    }

    public void inputUserName(String userName) throws IOException {
        web.input("reg.page.username", userName);
    }

    public void inputUserPassword(String userPassword) throws IOException {
        web.input("reg.page.password", userPassword);
    }

    public void inputUserConfirmPassword(String userConfirmPassword) throws IOException {
        web.input("reg.page.confirm.password", userConfirmPassword);
    }

    public void submitRegisterButton() throws IOException {
        web.clickButton("reg.page.register.button");
    }

    public void pageName() throws IOException {
        web.isElementPresent("reg.page.breadcrumb.current.page");
    }





}
