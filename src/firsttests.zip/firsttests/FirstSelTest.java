package firsttests;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;


import javax.swing.*;
import java.util.concurrent.TimeUnit;

import static junit.framework.TestCase.fail;

public class FirstSelTest {
    private WebDriver driver;
    private WebElementActions web;
    private String baseUrl;
    private StringBuffer verificationErrors = new StringBuffer();
    private String INCORRECT_LOGIN_ERROR = "  Имя пользователя и пароль не совпадают или у вас ещё нет учётной записи на сайте";
    private String EMPTY_LOGIN_ERROR = "  Пустой пароль не допускается";


    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.gecko.driver", "/Users/oleksandrzinoviev/Downloads/geckodriver");
        driver = new FirefoxDriver();
        web = new WebElementActions(driver);
        baseUrl = "https://torgoviy-dom.com.ua/";
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void incorrectLoginCredentialsTest() throws Exception {
        driver.get(baseUrl);

        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);

        homePage.clickLoginButton();
        loginPage.inputUserLogin("assds");
        loginPage.inputUserPassword("assdd");
        loginPage.clickLoginButton();
        loginPage.errorPopup();

//        boolean isErrorPopupDisplayed = isElementPresent(By.cssSelector(".ial-err"));
//        if (isErrorPopupDisplayed) {
//            WebElement errorPopup = driver.findElement(By.cssSelector(".ial-err"));
//            String popupText = errorPopup.getText();
//            boolean compareTextValue = INCORRECT_LOGIN_ERROR.equals(popupText);
//            if (compareTextValue) {
//                System.out.println("Pass Text on popup: " + popupText);
//            } else throw new Exception("Failed. Incorrect message displayed" + popupText);
//        } else throw new Exception("Error popup doesn't appered");

//        new Actions(driver)
//                .moveToElement(userText)
//                .keyDown(Keys.CONTROL)
//                .clickAndHold()
//                .moveToElement(userText)
//                .release()
//                .keyUp(Keys.CONTROL)
//                .perform();
    }


    @Test
    public void emptyLoginCredentialsTest() throws Exception {
        driver.get(baseUrl);

        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);

        homePage.clickLoginButton();
        loginPage.inputUserLogin("");
        loginPage.inputUserPassword("");
        loginPage.clickLoginButton();
        loginPage.errorPopup();

//        boolean isErrorPopupDisplayed = isElementPresent(By.cssSelector(".ial-err"));
//        if (isErrorPopupDisplayed) {
//            WebElement errorPopup = driver.findElement(By.cssSelector(".ial-err"));
//            String popupText = errorPopup.getText();
//            boolean compareTextValue = EMPTY_LOGIN_ERROR.equals(popupText);
//            if (compareTextValue) {
//                System.out.println("Pass. Text on popup: " + popupText);
//            } else throw new Exception("Failed. Incorrect message displayed");
//        } else throw new Exception("Error popup doesn't appered");
    }


    @Test
    public void correctLoginCredentialsTest() throws Exception {
        driver.get(baseUrl);

        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);
        homePage.clickLoginButton();
        loginPage.inputUserLogin("testlogin_alex");
        loginPage.inputUserPassword("12345678");
        loginPage.clickLoginButton();
        homePage.loggedUserNameControl();
    }


    @Test
    public void logoutTest() throws Exception {
        driver.get(baseUrl);

        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);
        homePage.clickLoginButton();
        loginPage.inputUserLogin("testlogin_alex");
        loginPage.inputUserPassword("12345678");
        loginPage.clickLoginButton();
        homePage.loggedUserNameControl();
        homePage.userLogout();
    }


    @Test
    public void userRegisterTest() throws Exception {
        driver.get(baseUrl);
        HomePage homePage = new HomePage(driver);
        RegisterPage registerPage = new RegisterPage(driver);
        homePage.clickRegisterButton();

        registerPage.pageName();

//        while (true) {
//
//            boolean isPageLoaded = isElementPresent(By.xpath(".//span[contains(text(),'Зарегистрироваться')]"));
//            if (isPageLoaded) {
//                break;
//            }
//            else continue;
//        }

        registerPage.inputUserFirstName("Fname1");
        registerPage.inputUserLastName("LName1");
        registerPage.inputUserMiddleName("Mname1");
        registerPage.inputUserEmail("myemail1@email.com");
        registerPage.inputUserConfirmEmail("myemail1@email.com");
        registerPage.inputUserPhone("0449999999");
        registerPage.inputUserMobPhone("0999999999");
        registerPage.inputUserName("new_user_name1");
        registerPage.inputUserPassword("12345678");
        registerPage.inputUserConfirmPassword("12345678");

        registerPage.submitRegisterButton();
//        Thread.sleep(1000000);
    }



    @After
    public void tearDown() throws Exception {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}