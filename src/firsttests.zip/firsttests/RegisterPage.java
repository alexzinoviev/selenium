package firsttests;

import org.openqa.selenium.WebDriver;

public class RegisterPage {

    WebElementActions web;

    public RegisterPage (WebDriver driver){
        web = new WebElementActions(driver);
    }


    public void inputUserFirstName(String firstName) {
        web.input(".//input[@id='f_name']", firstName);
    }

    public void inputUserLastName(String lastName) {
        web.input(".//input[@id='l_name']", lastName);
    }

    public void inputUserMiddleName(String middleName) {
        web.input(".//input[@id='m_name']", middleName);
    }

    public void inputUserEmail(String userEmail) {
        web.input(".//input[@id='email']", userEmail);
    }

    public void inputUserConfirmEmail(String userConfirmEmail) {
        web.input(".//input[@id='email2']", userConfirmEmail);
    }

    public void inputUserPhone(String userPhone) {
        web.input(".//input[@id='phone']", userPhone);
    }

    public void inputUserMobPhone(String userMobPhone) {
        web.input(".//input[@id='mobil_phone']",userMobPhone);
    }

    public void inputUserName(String userName) {
        web.input(".//input[@id='u_name']", userName);
    }

    public void inputUserPassword(String userPassword) {
        web.input(".//input[@id='password']", userPassword);
    }

    public void inputUserConfirmPassword(String userConfirmPassword) {
        web.input(".//input[@id='password_2']", userConfirmPassword);
    }

    public void submitRegisterButton() {
        web.submitButton(".//input[@value='Регистрация']");
    }

    public void pageName() {
        web.isElementPresent(".//span[contains(text(),'Зарегистрироваться')]");
    }





}
