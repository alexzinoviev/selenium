package firsttests;

import org.openqa.selenium.WebDriver;

public class HomePage {

    WebElementActions web;

    public HomePage (WebDriver driver) {
        web = new WebElementActions(driver);
    }

    public void clickLoginButton() {
        web.clickButton(".//*[@class='loginBtn']");
    }

    public void clickRegisterButton() {
        web.clickButton("//a[contains(@class,'regBtn')]/span");
    }

    public void loggedUserNameControl() {
//        web.getElement(".//span[contains(@class,'leftBtn')]");
        String text = web.getElementText(".//span[contains(@class,'leftBtn')]");
        System.out.println("Logged user name is: " + text);
    }

    public void userLogout() {
        web.clickButton(".//span[contains(@class,'rightBtn')]");
        web.clickButton(".//a[@class = 'logout']");
    }

}
