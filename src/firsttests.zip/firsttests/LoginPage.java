package firsttests;

import org.openqa.selenium.WebDriver;

public class LoginPage {

    WebElementActions web;

    public LoginPage (WebDriver driver) {
        web = new WebElementActions(driver);
    }


    public void inputUserLogin(String inputData) {
        web.input(".//input[@id='userTxt']", inputData);
    }

    public void inputUserPassword(String inputData) {
        web.input(".//input[@id='passTxt']", inputData);
    }

    public void clickLoginButton() {
        web.clickButton(".//*[@id='submitBtn']");
    }

    public void errorPopup() {
        boolean isPresent = web.isElementPresent(".//span[@class='ial-err']");
        System.out.println("Popup appeared " + isPresent);

        if (isPresent) {
            String popupErrorMessage = web.getElementText(".//span[@class='ial-err']");
            System.out.println("Error message is:" + popupErrorMessage);
        }
    }
}
